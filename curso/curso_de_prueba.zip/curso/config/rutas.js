var cssIndi = [];
var scriptIndi = [];